@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Data Laporan
	</h1>
</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Laporan Per Bulan</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-12">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Bulan</th>
							<th>Cetak Laporan</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($daftar_kategori as $kategori): ?>
						<tr>
							<td><?= date("F Y",strtotime($kategori->label)); ?></td>
							<td>
							<a href="/laporan/{{$kategori->label}}/pdf" class="btn btn-lg btn-primary"><i class="fa fa-print"></i></a>
							</td>
						</tr>
						<?php endforeach?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
@endsection
