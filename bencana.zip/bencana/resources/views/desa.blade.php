@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Desa
		<small>Admin</small>
	</h1>
</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Data Master Desa</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-4">
				@if(!isset($edit))
				<form action="/desa/simpan" method="POST">
				@else
				<form action="/desa/update" method="POST">
				@endif
					<div class="form-group">
						{{csrf_field()}}
						@if(isset($edit))
						<input type="hidden" name="id_desa" value="{{$desa->id_desa}}">
						@endif
						<div class="form-group">
							<label for="Kecamatan">Kecamatan: </label>
							<select name="kecamatan" id="Kecamatan" required class="form-control">
								<option value="">Pilih satu</option>
								@foreach($daftar_kecamatan as $kecamatan)
								<option value="{{$kecamatan->id_kecamatan}}"
								@if(isset($edit) and $kecamatan->id_kecamatan == $desa->kecamatan->id_kecamatan);
								selected
								@endif
								>{{$kecamatan->nama_kecamatan}}</option>
								@endforeach
							</select>
						</div>
						<div class="form-group">
							<label for="desa">Desa</label>
							<input type="text" id="desa" name="desa" class="form-control" required placeholder="Nama desa" 
							@if(isset($edit))
							value="{{$desa->nama_desa}}"
							@endif
							>
						</div>
						<div class="form-group">
							<label for="kades">Kades</label>
							<input type="text" id="kades" name="kades" class="form-control" required placeholder="Nama kades" 
							@if(isset($edit))
							value="{{$desa->kades}}"
							@endif
							>
						</div>
						<button type="submit" class="btn btn-primary pull-right">
						@if(!isset($edit))
						Tambah
						@else
						Simpan
						@endif
						</button>
					</div>
				</form>
			</div>
			<div class="col-md-8">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Kecamatan</th>
							<th>Desa</th>
							<th>Kades</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						@foreach($daftar_desa as $desa)
						<tr>
							<td>{{$no++}}</td>
							<td>{{$desa->kecamatan->nama_kecamatan}}</td>
							<td>{{$desa->nama_desa}}</td>
							<td>{{$desa->kades}}</td>
							<td>
								<a href="/desa/{{$desa->id_desa}}/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
								<a href="/desa/{{$desa->id_desa}}/hapus" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
@endsection