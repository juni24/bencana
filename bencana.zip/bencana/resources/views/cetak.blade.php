@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Data Laporan
	</h1>
	</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Laporan Per Bulan</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-12">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Kecamatan</th>
							<th>Desa</th>
							<th>Bencana</th>
							<th>Korban</th>
							<th>Alamat</th>
							<th>Tanggal</th>
							<th>Jam</th>
							<th>Keterangan</th>
							<th>Total Kerugian</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($laporan as $data): ?>
						<tr>
							<td>{{$data->nama_kecamatan}}</td>
							<td>{{$data->nama_desa}}</td>
							<td>{{$data->nama_bencana}}</td>
							<td>
							<ul class="test">
								<?php foreach ($korban as $lists): ?>
									@if($lists->id_bencana == $data->id_bencana)
									<li>{{$lists->nama_korban}}</li>
									@endif
								<?php endforeach; ?>
								</ul>
							</td>
							<td>{{$data->alamat}}</td>
							<td>{{$data->tanggal}}</td>
							<td>{{$data->jam}}</td>
							<td>{{$data->keterangan}}</td>
							<td>Rp. {{number_format($data->total_kerugian, 2, ',', '.')}}</td>
						</tr>
						<?php endforeach?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
@endsection
