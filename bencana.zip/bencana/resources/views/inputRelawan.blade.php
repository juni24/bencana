@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Data
		<small>Relawan</small>
	</h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Tambah data relawan</h3>
          </div>
          <form role="form" action="/relawan/simpan" method="post">
            {{csrf_field()}}
            <div class="box-body">
              <div class="form-group">
                <label for="Bencana">Bencana</label>
                <select name="bencana" id="Bencana" required class="form-control">
                  <option value="">Pilih satu</option>
				  {{var_dump($daftar_bencana)}}
					@foreach($daftar_bencana as $bencana)
                  <option value="{{$bencana->id_bencana}}">{{$bencana->kategori->nama_bencana}} di {{$bencana->desa->nama_desa}} pada {{$bencana->tanggal}}</option>
					@endforeach
                </select>
              </div>
              <div class="form-group">
                <label for="nama_instansi">Nama Instansi</label>
                <input type="text" class="form-control" name="nama_instansi" id="nama_instansi" placeholder="Nama Instansi" required>
              </div>
              <div class="form-group">
                <label for="jumlah_anggota">Jumlah Anggota
                <input type="number" min="1" name="jumlah_anggota" class="form-control" placeholder="Jumlah Anggota" id="jumlah_anggota"></label>
              </div>
              <div class="form-group">
                <label for="Keterangan">Keterangan</label>
                <input type="text" class="form-control" id="Keterangan" name="keterangan" placeholder="Keterangan">
              </div>
            </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</section>
@endsection