@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Users
		<small>Admin</small>
	</h1>
</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Data Master Users</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-4">
				@if(!isset($edit))
				<form action="/users/simpan" method="POST">
				@else
				<form action="/users/update" method="POST">
				@endif
					<div class="form-group">
						{{csrf_field()}}
						@if(isset($edit))
						<input type="hidden" name="id" value="{{$user->id}}">
						@endif
						<div class="form-group">
							<label for="role">Role: </label>
							<select name="role" id="role" required class="form-control">
								<option value="">Pilih satu</option>
								<option value="1"
								@if(isset($edit) && $user->role== 1)
								selected
								@endif
								>Petugas Lapangan</option>
								<option value="2"
								@if(isset($edit) && $user->role== 2)
								selected
								@endif
								>Petugas Kecamatan</option>
								<option value="3"
								@if(isset($edit) && $user->role== 3)
								selected
								@endif
								>Petugas Desa</option>
								<option value="4"
								@if(isset($edit) && $user->role== 4)
								selected
								@endif
								>Admin</option>
							</select>
						</div>
						<div class="form-group">
							<label for="nama_lengkap">Nama lengkap</label>
							<input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" required placeholder="Nama lengkap" 
							@if(isset($edit))
							value="{{$user->name}}"
							@endif
							>
						</div>
						<div class="form-group">
							<label for="username">Username</label>
							<input type="text" id="username" name="username" class="form-control" required placeholder="Username" 
							@if(isset($edit))
							value="{{$user->username}}"
							@endif
							>
						</div>
						<div class="form-group">
							@if(!isset($edit))
							<label for="password">Password</label>
							@else
							<label for="password">Password baru</label>
							@endif
							<input type="password" id="password" name="password" class="form-control"  
							@if(!isset($edit))
							required placeholder="Password"
							@else
							placeholder="Password baru"
							@endif
							>
						</div>
						<button type="submit" class="btn btn-primary pull-right">
						@if(!isset($edit))
						Tambah
						@else
						Simpan
						@endif
						</button>
					</div>
				</form>
			</div>
			<div class="col-md-8">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Role</th>
							<th>Nama</th>
							<th>Username</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						@foreach($users as $user)
						<tr>
							<td>{{$no++}}</td>
							<td>
							@if($user->role == 4)
							Admin
							@elseif($user->role == 3)
							Petugas Desa
							@elseif($user->role == 2)
							Petugas Kecamatan
							@else
							Petugas Lapangan
							@endif
							</td>
							<td>{{$user->name}}</td>
							<td>{{$user->username}}</td>
							<td>
								<a href="/users/{{$user->id}}/edit" title="Edit user" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
								<a href="/users/{{$user->id}}/hapus" title="Hapus user" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
@endsection