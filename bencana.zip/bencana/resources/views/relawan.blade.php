@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Relawan
		<small>Admin</small>
	</h1>
</section>

<section class="content">
<div class="box">
    <div class="box-body no-padding">
    	<a href="/relawan/input" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah data</a>
      <table class="table table-condensed">
			<thead>
				<tr>
					<th style="width: 10px">#</th>
					<th>Nama Instansi</th>
					<th>Jumlah Anggota</th>
					<th>Bencana</th>
					<th>Keterangan</th>
					<th>Aksi</th>
        </tr>
			</thead>
			<tbody>
			@foreach($list_relawan as $relawan)
				<tr>
					<td style="widtd: 10px">{{$no++}}</td>
					<td>{{$relawan->nama_instansi}}</td>
					<td>{{$relawan->jumlah_anggota}}</td>
					<td>{{$relawan->bencana->kategori->nama_bencana}}</td>
					<td>{{$relawan->keterangan}}</td>
					<td width=100>
					<a href="/relawan//detail" class="btn btn-primary btn-xs" title="Detail"><i class="fa fa-eye"></i></a>
					<a href="/relawan//edit" class="btn btn-info btn-xs" title="Edit"><i class="fa fa-edit"></i></a>
					<a href="/relawan//hapus" class="btn btn-danger btn-xs" title="Hapus"><i class="fa fa-trash"></i></a>
					</td>
        </tr>
				@endforeach
      </tbody>
			</table>
    </div>
  </div>
</section>
@endsection