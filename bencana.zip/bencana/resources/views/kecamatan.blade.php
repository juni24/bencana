@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Kecamatan
		<small>Admin</small>
	</h1>
</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Data Master Kecamatan</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-4">
				@if(!isset($edit))
				<form action="/kecamatan/simpan" method="POST">
				@else
				<form action="/kecamatan/update" method="POST">
				@endif
					<div class="form-group">
						{{csrf_field()}}
						@if(isset($edit))
						<input type="hidden" name="id_kecamatan" value="{{$kecamatan->id_kecamatan}}">
						@endif
						<label for="kecamatan">Kategori</label>
						<input type="text" id="kecamatan" name="kecamatan" class="form-control" placeholder="Nama kecamatan" 
						@if(isset($edit))
						value="{{$kecamatan->nama_kecamatan}}"
						@endif
						>
						<button type="submit" class="btn btn-primary pull-right">
						@if(!isset($edit))
						Tambah
						@else
						Simpan
						@endif
						</button>
					</div>
				</form>
			</div>
			<div class="col-md-8">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Kategori</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						@foreach($daftar_kecamatan as $kecamatan)
						<tr>
							<td>{{$no++}}</td>
							<td>{{$kecamatan->nama_kecamatan}}</td>
							<td>
								<a href="/kecamatan/{{$kecamatan->id_kecamatan}}/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
								<a href="/kecamatan/{{$kecamatan->id_kecamatan}}/hapus" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
@endsection