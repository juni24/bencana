@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Data
		<small>Bencana</small>
	</h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Detail data bencana</h3>
            </div>
            <div class="box-body">
              <div class="form-group">
                <label for="Kategori">Kategori</label><br/>
                {{$bencana->kategori->nama_bencana}}
              </div>
              <div class="form-group">
                <label for="Kecamatan">Kecamatan</label><br/>
                {{$bencana->desa->kecamatan->nama_kecamatan}}
              </div>
              <div class="form-group">
                <label for="Desa">Desa</label><br/>
                {{$bencana->desa->nama_desa}}
              </div>
              <div class="form-group">
                <label for="Tanggal">Tanggal</label><br/>
                {{$bencana->tanggal}}
              </div>
              <div class="form-group">
                <label for="Jam">Jam</label><br/>
                {{$bencana->jam}}
              </div>
              <div class="form-group">
                <label for="Alamat">Alamat</label><br/>
                {{$bencana->alamat}}
              </div>
              <div class="form-group">
                <label for="Total_kerugian">Total kerugian</label><br/>
                Rp. {{number_format($bencana->total_kerugian, 0, ',', '.')}}
              </div>
              <div class="form-group">
                <label for="Keterangan">Keterangan</label><br/>
                {{$bencana->keterangan}}
              </div>
              <div class="form-group">
                <label for="Gambar">Gambar</label><br/>
                <img src="{{$bencana->gambar}}">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="box box-success">
            <div class="box-header">
              @if(!isset($edited))
              <h1 class="box-title">Tambah Data Korban</h1>
              @else
              <a href="/bencana/{{$bencana->id_bencana}}/detail" title="Kembali" class="btn btn-success btn-sm"><i class="fa fa-chevron-left"></i></a><h1 class="box-title">Edit Data Korban</h1>
              @endif
            </div>
            <div class="box-body">
              @if(!isset($edited))
              <form method="post" action="/korban/simpan">
                {{csrf_field()}}
                <input type="hidden" name="bencana" value="{{$bencana->id_bencana}}">
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama">
                </div>
                <div class="form-group">
                  <label for="jk">Jenis Kelamin
                    <select name="jk" id="jk" class="form-control">
                      <option value="L">Laki-laki</option>
                      <option value="P">Perempuan</option>
                    </select>
                  </label>
                </div>
                <div class="form-group">
                  <label for="umur">Umur
                  <input type="number" class="form-control" id="umur" placeholder="Umur" name="umur">
                  </label>
                </div>
                <div class="form-group">
                  <label for="alamat">Alamat</label>
                  <input type="text" class="form-control" id="alamat" placeholder="Alamat" name="alamat">
                </div>
                <div class="form-group">
                  <label for="detail_kerugian">Detail Kerugian
                  <input type="number" class="form-control" id="detail_kerugian" placeholder="Detail Kerugian" name="detail_kerugian"></label>
                </div>
                <div class="form-group">
                  <label for="jenis_korban">Jenis Korban</label>
                  <select name="jenis_korban" id="jenis_korban" required class="form-control">
                    <option value="">Pilih satu</option>
                    <option value="Meninggal">Meninggal</option>
                    <option value="Luka-luka">Luka-luka</option>
                  </select>
                </div>
                <div class="form-group">
                  <button type="reset" class="btn btn-info">Reset</button>
                  <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
              </form>
              @else
              <form method="post" action="/korban/update">
              {{csrf_field()}}
                <input type="hidden" name="id_korban" value="{{$edited->id_korban}}">
                <input type="hidden" name="bencana" value="{{$bencana->id_bencana}}">
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" value="{{$edited->nama_korban}}">
                </div>
                <div class="form-group">
                  <label for="jk">Jenis Kelamin
                    <select name="jk" id="jk" class="form-control">
                      <option value="L" 
                      @if($edited->jenis_kelamin == 'L')
                      selected
                      @endif
                      >Laki-laki</option>
                      <option value="P" 
                      @if($edited->jenis_kelamin == 'P')
                      selected
                      @endif
                      >Perempuan</option>
                    </select>
                  </label>
                </div>
                <div class="form-group">
                  <label for="umur">Umur
                  <input type="number" class="form-control" id="umur" placeholder="Umur" name="umur" value="{{$edited->umur}}">
                  </label>
                </div>
                <div class="form-group">
                  <label for="alamat">Alamat</label>
                  <input type="text" class="form-control" id="alamat" placeholder="Alamat" name="alamat" value="{{$edited->alamat}}">
                </div>
                <div class="form-group">
                  <label for="detail_kerugian">Detail Kerugian
                  <input type="number" class="form-control" id="detail_kerugian" placeholder="Detail Kerugian" name="detail_kerugian" value="{{$edited->detail_kerugian}}"></label>
                </div>
                <div class="form-group">
                  <label for="jenis_korban">Jenis Korban</label>
                  <select name="jenis_korban" id="jenis_korban" required class="form-control">
                    <option value="">Pilih satu</option>
                    <option value="Meninggal"
                    @if($edited->jenis_korban == 'Meninggal')
                    selected
                    @endif
                    >Meninggal</option>
                    <option value="Luka-luka"
                    @if($edited->jenis_korban == 'Luka-luka')
                    selected
                    @endif
                    >Luka-luka</option>
                  </select>
                </div>
                <div class="form-group">
                  <button type="reset" class="btn btn-info">Reset</button>
                  <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
              </form>
              @endif
            </div>
          </div>
        </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box box-danger">
          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenis kelamin</th>
                <th>Umur</th>
                <th>Alamat</th>
                <th>Kerugian</th>
                <th>Korban</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              @foreach($korban as $korbane)
              <tr>
                <td>{{$no++}}</td>
                <td>{{$korbane->nama_korban}}</td>
                <td>
                @if($korbane->jenis_kelamin == 'L')                
                Laki-laki
                @else
                Perempuan
                @endif
                </td>
                <td>{{$korbane->umur}}</td>
                <td>{{$korbane->alamat}}</td>
                <td>Rp. {{number_format($korbane->detail_kerugian, 0, ",", ".")}}</td>
                <td>{{$korbane->jenis_korban}}</td>
                <td>
                  <a href="/bencana/{{$bencana->id_bencana}}/detail/{{$korbane->id_korban}}/edit" class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a> 
                  <a href="/korban/{{$korbane->id_korban}}/{{$bencana->id_bencana}}/hapus" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
</section>
@endsection