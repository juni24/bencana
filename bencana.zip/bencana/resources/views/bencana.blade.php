@extends('master')
@section('content')
<section class="content-header">
	<h1>
	Bencana
		@if(Auth::user()->role == 4)
		<small>Admin</small>
		@endif
	</h1>
</section>

<section class="content">
<div class="box">
    <div class="box-body no-padding">
			@if(Auth::user()->role == 4)
    	<a href="/bencana/input" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah data</a>
			@endif
      <table class="table table-condensed">
        <tbody><tr>
          <th style="width: 10px">#</th>
          <th>Kategori</th>
			<th>Desa</th>
			<th>Tanggal</th>
			<th>Alamat</th>
			<th>Total Kerugian</th>
			<th>Keterangan</th>
			<th>Aksi</th>
        </tr>
        @foreach($bencana as $data)
        <tr>
			<td style="width: 15px">#</td>
			<td>{{$data->kategori->nama_bencana}}</td>
			<td>{{$data->desa->nama_desa}}</td>
			<td>{{$data->tanggal}}</td>
			<td>{{$data->alamat}}</td>
			<td>Rp. {{number_format($data->total_kerugian, 2, ',', '.')}}</td>
			<td>{{$data->keterangan}}</td>
			<td width=120>
				@if(Auth::user()->role == 2 and $data->valid != 1)
				<a href="/bencana/{{$data->id_bencana}}/validasi" class="btn btn-success btn-xs" title="Hapus"><i class="fa fa-check"></i></a>
				@endif
				@if($data->valid==1)
					<span class="bg-success">Valid</span>
				@endif
				<a href="/bencana/{{$data->id_bencana}}/detail" class="btn btn-primary btn-xs" title="Detail"><i class="fa fa-eye"></i></a>
				@if(Auth::user()->role == 4)
				<a href="/bencana/{{$data->id_bencana}}/edit" class="btn btn-info btn-xs" title="Edit"><i class="fa fa-edit"></i></a>
				<a href="/bencana/{{$data->id_bencana}}/hapus" class="btn btn-danger btn-xs" title="Hapus"><i class="fa fa-trash"></i></a>
				@endif
			</td>
        </tr>
        @endforeach
      </tbody></table>
    </div>
  </div>
</section>
@endsection
