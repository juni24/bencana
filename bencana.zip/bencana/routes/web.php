<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Admin@index');
Route::get('/login', 'Admin@login');
Route::post('/login', 'Admin@doLogin');
Route::group(['middleware'=>['cekuser']], function() {
	Route::get('/', 'Admin@index');
	Route::get('/logout', 'Admin@logout');
	Route::get('/bencana', 'Admin@bencana');
	Route::get('/bencana/input', 'Admin@inputBencana');
	Route::post('/bencana/simpan', 'Admin@simpanBencana');
	Route::get('/bencana/{id}/edit', 'Admin@editBencana');
	Route::post('/bencana/update', 'Admin@updateBencana');
	Route::get('/bencana/{id}/hapus', 'Admin@hapusBencana');
	Route::get('/bencana/{id}/detail', 'Admin@detailBencana');
	Route::get('/bencana/{id}/validasi', 'Admin@validasiBencana');
	Route::get('/logout', 'Admin@logout');

	Route::post('/korban/simpan', 'Admin@simpanKorban');
	Route::get('/bencana/{id}/detail/{id_korban}/edit', 'Admin@editKorban');
	Route::post('/korban/update', 'Admin@updateKorban');
	Route::get('/korban/{id_korban}/{id_bencana}/hapus', 'Admin@hapusKorban');

	/* Route::get('/relawan', 'ControllerRelawan@index');
	Route::get('/relawan/input', 'ControllerRelawan@inputRelawan');
	Route::post('/relawan/simpan', 'ControllerRelawan@simpanRelawan');
	Route::get('/relawan/{id}/edit', 'ControllerRelawan@editRelawan');
	Route::post('/relawan/update', 'ControllerRelawan@updateRelawan');
	Route::get('/relawan/{id}/hapus', 'ControllerRelawan@hapusRelawan'); */

	Route::get('/kecamatan', 'ControllerKecamatan@index');
	Route::get('/kecamatan/input', 'ControllerKecamatan@inputKecamatan');
	Route::post('/kecamatan/simpan', 'ControllerKecamatan@simpanKecamatan');
	Route::get('/kecamatan/{id}/edit', 'ControllerKecamatan@editKecamatan');
	Route::post('/kecamatan/update', 'ControllerKecamatan@updateKecamatan');
	Route::get('/kecamatan/{id}/hapus', 'ControllerKecamatan@hapusKecamatan');
	Route::get('/kecamatan/{id}/desa', 'ControllerKecamatan@ambilDesa');

	Route::get('/desa', 'ControllerDesa@index');
	Route::get('/desa/input', 'ControllerDesa@inputDesa');
	Route::post('/desa/simpan', 'ControllerDesa@simpanDesa');
	Route::get('/desa/{id}/edit', 'ControllerDesa@editDesa');
	Route::post('/desa/update', 'ControllerDesa@updateDesa');
	Route::get('/desa/{id}/hapus', 'ControllerDesa@hapusDesa');

	Route::get('/kategori', 'ControllerKategori@index');
	Route::get('/kategori/input', 'ControllerKategori@inputKategori');
	Route::post('/kategori/simpan', 'ControllerKategori@simpanKategori');
	Route::get('/kategori/{id}/edit', 'ControllerKategori@editKategori');
	Route::post('/kategori/update', 'ControllerKategori@updateKategori');
	Route::get('/kategori/{id}/hapus', 'ControllerKategori@hapusKategori');

	Route::get('/users', 'ControllerUsers@index');
	Route::post('/users/simpan', 'ControllerUsers@simpanUser');
	Route::get('/users/{id}/edit', 'ControllerUsers@editUser');
	Route::post('/users/update', 'ControllerUsers@updateUser');
	Route::get('/users/{id}/hapus', 'ControllerUsers@hapusUser');
  Route::get('/kecamatan', 'ControllerKecamatan@index');
  Route::get('/laporan', 'ControllerLaporan@laporan');
  Route::get('/laporan/{tanggal}/cetak', 'ControllerLaporan@cetak');
  Route::get('/laporan/{tanggal}/pdf', 'ControllerLaporan@exportPDF');

});

Route::post('/simpanbencana', 'ControllerAPI@simpan');
Route::get('/api/bencana', 'Admin@APIDataBencana');
