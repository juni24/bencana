<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Data Laporan
	</h1>
	</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Laporan Per Bulan</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-12">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Kecamatan</th>
							<th>Desa</th>
							<th>Bencana</th>
							<th>Korban</th>
							<th>Alamat</th>
							<th>Tanggal</th>
							<th>Jam</th>
							<th>Keterangan</th>
							<th>Total Kerugian</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($laporan as $data): ?>
						<tr>
							<td><?php echo e($data->nama_kecamatan); ?></td>
							<td><?php echo e($data->nama_desa); ?></td>
							<td><?php echo e($data->nama_bencana); ?></td>
							<td>
							<ul class="test">
								<?php foreach ($korban as $lists): ?>
									<?php if($lists->id_bencana == $data->id_bencana): ?>
									<li><?php echo e($lists->nama_korban); ?></li>
									<?php endif; ?>
								<?php endforeach; ?>
								</ul>
							</td>
							<td><?php echo e($data->alamat); ?></td>
							<td><?php echo e($data->tanggal); ?></td>
							<td><?php echo e($data->jam); ?></td>
							<td><?php echo e($data->keterangan); ?></td>
							<td>Rp. <?php echo e(number_format($data->total_kerugian, 2, ',', '.')); ?></td>
						</tr>
						<?php endforeach?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>