<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Data
		<small>Bencana</small>
	</h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Detail data bencana</h3>
            </div>
            <div class="box-body">
              <div class="form-group">
                <label for="Kategori">Kategori</label><br/>
                <?php echo e($bencana->kategori->nama_bencana); ?>

              </div>
              <div class="form-group">
                <label for="Kecamatan">Kecamatan</label><br/>
                <?php echo e($bencana->desa->kecamatan->nama_kecamatan); ?>

              </div>
              <div class="form-group">
                <label for="Desa">Desa</label><br/>
                <?php echo e($bencana->desa->nama_desa); ?>

              </div>
              <div class="form-group">
                <label for="Tanggal">Tanggal</label><br/>
                <?php echo e($bencana->tanggal); ?>

              </div>
              <div class="form-group">
                <label for="Jam">Jam</label><br/>
                <?php echo e($bencana->jam); ?>

              </div>
              <div class="form-group">
                <label for="Alamat">Alamat</label><br/>
                <?php echo e($bencana->alamat); ?>

              </div>
              <div class="form-group">
                <label for="Total_kerugian">Total kerugian</label><br/>
                Rp. <?php echo e(number_format($bencana->total_kerugian, 0, ',', '.')); ?>

              </div>
              <div class="form-group">
                <label for="Keterangan">Keterangan</label><br/>
                <?php echo e($bencana->keterangan); ?>

              </div>
              <div class="form-group">
                <label for="Gambar">Gambar</label><br/>
                <img src="<?php echo e($bencana->gambar); ?>">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="box box-success">
            <div class="box-header">
              <?php if(!isset($edited)): ?>
              <h1 class="box-title">Tambah Data Korban</h1>
              <?php else: ?>
              <a href="/bencana/<?php echo e($bencana->id_bencana); ?>/detail" title="Kembali" class="btn btn-success btn-sm"><i class="fa fa-chevron-left"></i></a><h1 class="box-title">Edit Data Korban</h1>
              <?php endif; ?>
            </div>
            <div class="box-body">
              <?php if(!isset($edited)): ?>
              <form method="post" action="/korban/simpan">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="bencana" value="<?php echo e($bencana->id_bencana); ?>">
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama">
                </div>
                <div class="form-group">
                  <label for="jk">Jenis Kelamin
                    <select name="jk" id="jk" class="form-control">
                      <option value="L">Laki-laki</option>
                      <option value="P">Perempuan</option>
                    </select>
                  </label>
                </div>
                <div class="form-group">
                  <label for="umur">Umur
                  <input type="number" class="form-control" id="umur" placeholder="Umur" name="umur">
                  </label>
                </div>
                <div class="form-group">
                  <label for="alamat">Alamat</label>
                  <input type="text" class="form-control" id="alamat" placeholder="Alamat" name="alamat">
                </div>
                <div class="form-group">
                  <label for="detail_kerugian">Detail Kerugian
                  <input type="number" class="form-control" id="detail_kerugian" placeholder="Detail Kerugian" name="detail_kerugian"></label>
                </div>
                <div class="form-group">
                  <label for="jenis_korban">Jenis Korban</label>
                  <select name="jenis_korban" id="jenis_korban" required class="form-control">
                    <option value="">Pilih satu</option>
                    <option value="Meninggal">Meninggal</option>
                    <option value="Luka-luka">Luka-luka</option>
                  </select>
                </div>
                <div class="form-group">
                  <button type="reset" class="btn btn-info">Reset</button>
                  <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
              </form>
              <?php else: ?>
              <form method="post" action="/korban/update">
              <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id_korban" value="<?php echo e($edited->id_korban); ?>">
                <input type="hidden" name="bencana" value="<?php echo e($bencana->id_bencana); ?>">
                <div class="form-group">
                  <label for="nama">Nama</label>
                  <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" value="<?php echo e($edited->nama_korban); ?>">
                </div>
                <div class="form-group">
                  <label for="jk">Jenis Kelamin
                    <select name="jk" id="jk" class="form-control">
                      <option value="L" 
                      <?php if($edited->jenis_kelamin == 'L'): ?>
                      selected
                      <?php endif; ?>
                      >Laki-laki</option>
                      <option value="P" 
                      <?php if($edited->jenis_kelamin == 'P'): ?>
                      selected
                      <?php endif; ?>
                      >Perempuan</option>
                    </select>
                  </label>
                </div>
                <div class="form-group">
                  <label for="umur">Umur
                  <input type="number" class="form-control" id="umur" placeholder="Umur" name="umur" value="<?php echo e($edited->umur); ?>">
                  </label>
                </div>
                <div class="form-group">
                  <label for="alamat">Alamat</label>
                  <input type="text" class="form-control" id="alamat" placeholder="Alamat" name="alamat" value="<?php echo e($edited->alamat); ?>">
                </div>
                <div class="form-group">
                  <label for="detail_kerugian">Detail Kerugian
                  <input type="number" class="form-control" id="detail_kerugian" placeholder="Detail Kerugian" name="detail_kerugian" value="<?php echo e($edited->detail_kerugian); ?>"></label>
                </div>
                <div class="form-group">
                  <label for="jenis_korban">Jenis Korban</label>
                  <select name="jenis_korban" id="jenis_korban" required class="form-control">
                    <option value="">Pilih satu</option>
                    <option value="Meninggal"
                    <?php if($edited->jenis_korban == 'Meninggal'): ?>
                    selected
                    <?php endif; ?>
                    >Meninggal</option>
                    <option value="Luka-luka"
                    <?php if($edited->jenis_korban == 'Luka-luka'): ?>
                    selected
                    <?php endif; ?>
                    >Luka-luka</option>
                  </select>
                </div>
                <div class="form-group">
                  <button type="reset" class="btn btn-info">Reset</button>
                  <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
              </form>
              <?php endif; ?>
            </div>
          </div>
        </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box box-danger">
          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenis kelamin</th>
                <th>Umur</th>
                <th>Alamat</th>
                <th>Kerugian</th>
                <th>Korban</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $korban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $korbane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($korbane->nama_korban); ?></td>
                <td>
                <?php if($korbane->jenis_kelamin == 'L'): ?>                
                Laki-laki
                <?php else: ?>
                Perempuan
                <?php endif; ?>
                </td>
                <td><?php echo e($korbane->umur); ?></td>
                <td><?php echo e($korbane->alamat); ?></td>
                <td>Rp. <?php echo e(number_format($korbane->detail_kerugian, 0, ",", ".")); ?></td>
                <td><?php echo e($korbane->jenis_korban); ?></td>
                <td>
                  <a href="/bencana/<?php echo e($bencana->id_bencana); ?>/detail/<?php echo e($korbane->id_korban); ?>/edit" class="btn btn-info btn-xs"><i class="fa fa-edit"></i></a> 
                  <a href="/korban/<?php echo e($korbane->id_korban); ?>/<?php echo e($bencana->id_bencana); ?>/hapus" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>