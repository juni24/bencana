<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Dashboard
		<small>Admin</small>
	</h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-md-6">
			<div class="box box-primary">
				<div class="box-header with-border">
					<i class="fa fa-bar-chart-o"></i>

					<h3 class="box-title">Persentase Bencana</h3>

					<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
					</button>
					<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
					</div>
				</div>
				<div class="box-body">
					<div id="donut-chart" style="height: 300px;"></div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="box box-primary">
				<div class="box-header with-border">
					<i class="fa fa-bar-chart-o"></i>

					<h3 class="box-title">Data Bencana Per Bulan</h3>

					<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
					</button>
					<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
					</div>
				</div>
				<div class="box-body">
					<div id="bar-chart" style="height: 300px;"></div>
				</div>
				<!-- /.box-body-->
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- FLOT CHARTS -->
<script src="<?php echo e(URL::asset('bower_components/Flot/jquery.flot.js')); ?>"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="<?php echo e(URL::asset('bower_components/Flot/jquery.flot.resize.js')); ?>"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="<?php echo e(URL::asset('bower_components/Flot/jquery.flot.pie.js')); ?>"></script>
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="<?php echo e(URL::asset('bower_components/Flot/jquery.flot.categories.js')); ?>"></script>
<script>
var bar_data = {
	// [{sdsd, wew}, {ewe, ewe}]
	data : <?php echo $pertahun; ?>,
	color: '#3c8dbc'
}
$.plot('#bar-chart', [bar_data], {
	grid  : {
	borderWidth: 1,
	borderColor: '#f3f3f3',
	tickColor  : '#f3f3f3'
	},
	series: {
	bars: {
		show    : true,
		barWidth: 0.5,
		align   : 'center'
	}
	},
	xaxis : {
	mode      : 'categories',
	tickLength: 0
	}
})
var donutData = <?php echo $bencana; ?>;
    $.plot('#donut-chart', donutData, {
      series: {
        pie: {
          show       : true,
          radius     : 1,
          innerRadius: 0.5,
          label      : {
            show     : true,
            radius   : 2 / 3,
            formatter: labelFormatter,
            threshold: 0.1
          }

        }
      },
      legend: {
        show: false
      }
    })
    /*
     * END DONUT CHART
     */
	function labelFormatter(label, series) {
    return '<div style="font-size:13px; text-align:center; padding:2px; color: #fff; font-weight: 600;">'
      + label
      + '<br>'
      + Math.round(series.percent) + '%</div>'
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>