<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Users
		<small>Admin</small>
	</h1>
</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Data Master Users</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-4">
				<?php if(!isset($edit)): ?>
				<form action="/users/simpan" method="POST">
				<?php else: ?>
				<form action="/users/update" method="POST">
				<?php endif; ?>
					<div class="form-group">
						<?php echo e(csrf_field()); ?>

						<?php if(isset($edit)): ?>
						<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
						<?php endif; ?>
						<div class="form-group">
							<label for="role">Role: </label>
							<select name="role" id="role" required class="form-control">
								<option value="">Pilih satu</option>
								<option value="1"
								<?php if(isset($edit) && $user->role== 1): ?>
								selected
								<?php endif; ?>
								>Petugas Lapangan</option>
								<option value="2"
								<?php if(isset($edit) && $user->role== 2): ?>
								selected
								<?php endif; ?>
								>Petugas Kecamatan</option>
								<option value="3"
								<?php if(isset($edit) && $user->role== 3): ?>
								selected
								<?php endif; ?>
								>Petugas Desa</option>
								<option value="4"
								<?php if(isset($edit) && $user->role== 4): ?>
								selected
								<?php endif; ?>
								>Admin</option>
							</select>
						</div>
						<div class="form-group">
							<label for="nama_lengkap">Nama lengkap</label>
							<input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" required placeholder="Nama lengkap" 
							<?php if(isset($edit)): ?>
							value="<?php echo e($user->name); ?>"
							<?php endif; ?>
							>
						</div>
						<div class="form-group">
							<label for="username">Username</label>
							<input type="text" id="username" name="username" class="form-control" required placeholder="Username" 
							<?php if(isset($edit)): ?>
							value="<?php echo e($user->username); ?>"
							<?php endif; ?>
							>
						</div>
						<div class="form-group">
							<?php if(!isset($edit)): ?>
							<label for="password">Password</label>
							<?php else: ?>
							<label for="password">Password baru</label>
							<?php endif; ?>
							<input type="password" id="password" name="password" class="form-control"  
							<?php if(!isset($edit)): ?>
							required placeholder="Password"
							<?php else: ?>
							placeholder="Password baru"
							<?php endif; ?>
							>
						</div>
						<button type="submit" class="btn btn-primary pull-right">
						<?php if(!isset($edit)): ?>
						Tambah
						<?php else: ?>
						Simpan
						<?php endif; ?>
						</button>
					</div>
				</form>
			</div>
			<div class="col-md-8">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Role</th>
							<th>Nama</th>
							<th>Username</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td>
							<?php if($user->role == 4): ?>
							Admin
							<?php elseif($user->role == 3): ?>
							Petugas Desa
							<?php elseif($user->role == 2): ?>
							Petugas Kecamatan
							<?php else: ?>
							Petugas Lapangan
							<?php endif; ?>
							</td>
							<td><?php echo e($user->name); ?></td>
							<td><?php echo e($user->username); ?></td>
							<td>
								<a href="/users/<?php echo e($user->id); ?>/edit" title="Edit user" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
								<a href="/users/<?php echo e($user->id); ?>/hapus" title="Hapus user" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>