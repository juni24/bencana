<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
  Data
    <small>Bencana</small>
  </h1>
</section>

<!-- Main content -->
<section class="content">
  <div class="row">
      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit data bencana</h3>
          </div>
          <form role="form" action="/bencana/update" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id_bencana" value="<?php echo e($id); ?>">
            <div class="box-body">
              <div class="form-group">
                <label for="Kategori">Kategori</label>
                <select name="Kategori" id="Kategori" required class="form-control">
                  <option value="">Pilih satu</option>
                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kat->id_kategori); ?>" 
                    <?php if($bencana->id_kategori == $kat->id_kategori): ?>
                    selected
                    <?php endif; ?>><?php echo e($kat->nama_bencana); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="Kecamatan">Kecamatan</label>
                <select name="Kecamatan" id="Kecamatan" required class="form-control">
                  <option value="">Pilih satu</option>
                  <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kec->id_kecamatan); ?>"
                    <?php if($bencana->desa->kecamatan->id_kecamatan == $kec->id_kecamatan): ?>
                    selected
                    <?php endif; ?>><?php echo e($kec->nama_kecamatan); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="Desa">Desa</label>
                <select name="Desa" id="Desa" required class="form-control">
                  <option value="">Pilih satu</option>
                  <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($ds->id_desa); ?>"
                    <?php if($bencana->id_desa == $ds->id_desa): ?>
                    selected
                    <?php endif; ?>><?php echo e($ds->nama_desa); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="Tanggal">Tanggal</label>
                <input type="date" class="form-control" name="Tanggal" id="Tanggal" placeholder="dd/mm/yyyy" value="<?php echo e($bencana->tanggal); ?>">
              </div>
              <div class="form-group">
                <label for="Jam">Jam
                <input type="number" max="12" min="0" name="Jam" class="form-control" placeholder="Jam" id="Jam" value="<?php echo e($jam); ?>"> : <input type="number" class="form-control" max="60" min="0" placeholder="Menit" id="Menit" name="Menit" value="<?php echo e($menit); ?>"></label>
              </div>
              <div class="form-group">
                <label for="Alamat">Alamat</label>
                <input type="text" class="form-control" id="Alamat" name="Alamat" placeholder="Alamat" value="<?php echo e($bencana->alamat); ?>">
              </div>
              <div class="form-group">
                <label for="Total_kerugian">Total kerugian</label>
                <input type="number" class="form-control" id="Total_kerugian" placeholder="Total kerugian" name="Total_kerugian" value=<?php echo e($bencana->total_kerugian); ?>>
              </div>
              <div class="form-group">
                <label for="Keterangan">Keterangan</label>
                <input type="text" class="form-control" id="Keterangan" name="Keterangan" placeholder="Keterangan" value="<?php echo e($bencana->keterangan); ?>">
              </div>
              <div class="form-group">
                <label for="Gambar">Gambar</label>
                <input type="file" class="form-control" id="Gambar" placeholder="Gambar">
              </div>
            </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>