<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Laporan</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>"> -->
    <!-- Font Awesome -->
    <!-- <link rel="stylesheet" href="<?php echo e(URL::asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>"> -->
  </head>
  <body>
    <section class="content-header" >
    	<h3 class=""width=1000 align=center>
    	REKAPITULASI DATA JUMLAH OBYEK BENCANA ALAM
      <br> DI KECAMATAN SE KABUPATEN PONOROGO
    </h3>
    </section>

    <section class="content">
    <div class="box box-primary">
    	<div class="box-header with-border">
    		<!-- <h3 class="box-title" align=center >Laporan Per Bulan</h3> -->
    	</div>
        <div class="box-body">
    		<div class="row">
    			<div class="col-md-12">
    				<table class="table table-bordered" width=200 align=center border=1 cellspacing=0 cellpadding=10>
    					<thead>
    						<tr>
    							<th>Kecamatan</th>
    							<th>Desa</th>
    							<th>Bencana</th>
    							<th>Korban</th>
    							<th>Alamat</th>
    							<th>Tanggal</th>
    							<th>Jam</th>
    							<th>Keterangan</th>
    							<th>Total Kerugian</th>
    						</tr>
    					</thead>
    					<tbody>
    						<?php foreach($laporan as $data): ?>
    						<tr>
    							<td><?php echo e($data->nama_kecamatan); ?></td>
    							<td><?php echo e($data->nama_desa); ?></td>
    							<td><?php echo e($data->nama_bencana); ?></td>
    							<td>
    							<ul class="test">
    								<?php foreach ($korban as $lists): ?>
    									<?php if($lists->id_bencana == $data->id_bencana): ?>
    									<li><?php echo e($lists->nama_korban); ?></li>
    									<?php endif; ?>
    								<?php endforeach; ?>
    								</ul>
    							</td>
    							<td><?php echo e($data->alamat); ?></td>
    							<td><?php echo e($data->tanggal); ?></td>
    							<td><?php echo e($data->jam); ?></td>
    							<td><?php echo e($data->keterangan); ?></td>
    							<td>Rp. <?php echo e(number_format($data->total_kerugian, 2, ',', '.')); ?></td>
    						</tr>
    						<?php endforeach?>
    					</tbody>
    				</table>
    			</div>
    		</div>
        </div>
      </div>
    </section>
  </body>
</html>
