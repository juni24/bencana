<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Kategori
		<small>Admin</small>
	</h1>
</section>

<section class="content">
<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">Data Master Kategori</h3>
	</div>
    <div class="box-body">
		<div class="row">
			<div class="col-md-4">
				<?php if(!isset($edit)): ?>
				<form action="/kategori/simpan" method="POST">
				<?php else: ?>
				<form action="/kategori/update" method="POST">
				<?php endif; ?>
					<div class="form-group">
						<?php echo e(csrf_field()); ?>

						<?php if(isset($edit)): ?>
						<input type="hidden" name="id_kategori" value="<?php echo e($kategori->id_kategori); ?>">
						<?php endif; ?>
						<label for="kategori">Kategori</label>
						<input type="text" id="kategori" name="kategori" class="form-control" placeholder="Nama kategori" 
						<?php if(isset($edit)): ?>
						value="<?php echo e($kategori->nama_bencana); ?>"
						<?php endif; ?>
						>
						<button type="submit" class="btn btn-primary pull-right">
						<?php if(!isset($edit)): ?>
						Tambah
						<?php else: ?>
						Simpan
						<?php endif; ?>
						</button>
					</div>
				</form>
			</div>
			<div class="col-md-8">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Kategori</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $daftar_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($kategori->nama_bencana); ?></td>
							<td>
								<a href="/kategori/<?php echo e($kategori->id_kategori); ?>/edit" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
								<a href="/kategori/<?php echo e($kategori->id_kategori); ?>/hapus" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>