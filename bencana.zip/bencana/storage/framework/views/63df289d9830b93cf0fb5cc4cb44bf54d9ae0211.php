<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Bencana
		<?php if(Auth::user()->role == 4): ?>
		<small>Admin</small>
		<?php endif; ?>
	</h1>
</section>

<section class="content">
<div class="box">
    <div class="box-body no-padding">
			<?php if(Auth::user()->role == 4): ?>
    	<a href="/bencana/input" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah data</a>
			<?php endif; ?>
      <table class="table table-condensed">
        <tbody><tr>
          <th style="width: 10px">#</th>
          <th>Kategori</th>
			<th>Desa</th>
			<th>Tanggal</th>
			<th>Alamat</th>
			<th>Total Kerugian</th>
			<th>Keterangan</th>
			<th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $bencana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
			<td style="width: 15px">#</td>
			<td><?php echo e($data->kategori->nama_bencana); ?></td>
			<td><?php echo e($data->desa->nama_desa); ?></td>
			<td><?php echo e($data->tanggal); ?></td>
			<td><?php echo e($data->alamat); ?></td>
			<td>Rp. <?php echo e(number_format($data->total_kerugian, 2, ',', '.')); ?></td>
			<td><?php echo e($data->keterangan); ?></td>
			<td width=120>
				<?php if(Auth::user()->role == 2 and $data->valid != 1): ?>
				<a href="/bencana/<?php echo e($data->id_bencana); ?>/validasi" class="btn btn-success btn-xs" title="Hapus"><i class="fa fa-check"></i></a>
				<?php endif; ?>
				<?php if($data->valid==1): ?>
					<span class="bg-success">Valid</span>
				<?php endif; ?>
				<a href="/bencana/<?php echo e($data->id_bencana); ?>/detail" class="btn btn-primary btn-xs" title="Detail"><i class="fa fa-eye"></i></a>
				<?php if(Auth::user()->role == 4): ?>
				<a href="/bencana/<?php echo e($data->id_bencana); ?>/edit" class="btn btn-info btn-xs" title="Edit"><i class="fa fa-edit"></i></a>
				<a href="/bencana/<?php echo e($data->id_bencana); ?>/hapus" class="btn btn-danger btn-xs" title="Hapus"><i class="fa fa-trash"></i></a>
				<?php endif; ?>
			</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody></table>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>