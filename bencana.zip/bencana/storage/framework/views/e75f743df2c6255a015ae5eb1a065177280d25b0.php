<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>
	Data
		<small>Bencana</small>
	</h1>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Tambah data bencana</h3>
          </div>
          <form role="form" action="/bencana/simpan" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
              <div class="form-group">
                <label for="Kategori">Kategori</label>
                <select name="Kategori" required id="Kategori" required class="form-control">
                  <option value="">Pilih satu</option>
                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kat->id_kategori); ?>"><?php echo e($kat->nama_bencana); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="Kecamatan">Kecamatan</label>
                <select name="Kecamatan" required id="Kecamatan" required onchange="ambilDesa(this.value)" class="form-control">
                  <option value="">Pilih satu</option>
                  <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kec->id_kecamatan); ?>"><?php echo e($kec->nama_kecamatan); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="Desa">Desa</label>
                <select name="Desa" required disabled id="Desa" required class="form-control">
                  <option value="">Pilih satu</option>
                  <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($ds->id_desa); ?>"><?php echo e($ds->nama_desa); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="Tanggal">Tanggal</label>
                <input type="date" required class="form-control" name="Tanggal" id="Tanggal" placeholder="dd/mm/yyyy">
              </div>
              <div class="form-group">
                <label for="Jam">Jam
                <input type="number" required max="12" min="0" name="Jam" class="form-control" placeholder="Jam" id="Jam"> : <input type="number" class="form-control" max="60" min="0" placeholder="Menit" id="Menit" name="Menit"></label>
              </div>
              <div class="form-group">
                <label for="Alamat">Alamat</label>
                <input type="text" required class="form-control" id="Alamat" name="Alamat" placeholder="Alamat">
              </div>
              <div class="form-group">
                <label for="Total_kerugian">Total kerugian</label>
                <input type="number" required class="form-control" id="Total_kerugian" placeholder="Total kerugian" name="Total_kerugian">
              </div>
              <div class="form-group">
                <label for="Keterangan">Keterangan</label>
                <input type="text" required class="form-control" id="Keterangan" name="Keterangan" placeholder="Keterangan">
              </div>
              <div class="form-group">
                <label for="Gambar">Gambar</label>
                <input type="file" class="form-control" id="Gambar" placeholder="Gambar">
              </div>
            </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
var psn, pesan1;
  function ambilDesa(idkecamatan) {
    $('#Desa').prop('disabled', true);
    $.ajax({
      url: '/kecamatan/'+idkecamatan+'/desa',
      dataType: 'json',
      success: function(pesan) {
          $('#Desa').children().remove();
          $('#Desa').append("<option value=''>Pilih satu</option>");
          pesan1 = pesan;
          for(psn in pesan) {
            $('#Desa').append("<option value='"+pesan[psn].id_desa+"'>"+pesan[psn].nama_desa+"</option>");
          }
          $('#Desa').prop('disabled', false);
      },
      error: function(status, xhr, dkk) {
        console.log(status);
      }
    });
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>